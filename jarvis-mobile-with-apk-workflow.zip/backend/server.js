/**
 * J.A.R.V.I.S. Mobile — Secure OpenRouter Backend Proxy
 * 
 * Safely manages OPENROUTER_API_KEY on the server side without exposing it to client APKs.
 */
require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Health Check
app.get('/health', (req, res) => {
  const hasKey = Boolean(process.env.OPENROUTER_API_KEY);
  res.json({
    status: 'ONLINE',
    service: 'JARVIS OpenRouter Proxy',
    keyConfigured: hasKey,
    timestamp: new Date().toISOString()
  });
});

// Chat Completions Proxy
app.post('/api/chat', async (req, res) => {
  const apiKey = process.env.OPENROUTER_API_KEY;

  if (!apiKey) {
    return res.status(500).json({
      error: {
        message: 'OPENROUTER_API_KEY is not configured in backend environment variables. Please set it in your .env or hosting environment.'
      }
    });
  }

  const { model, messages, temperature = 0.7, max_tokens = 1000 } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({
      error: {
        message: 'Invalid payload: "messages" array is required.'
      }
    });
  }

  try {
    const openRouterResponse = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'HTTP-Referer': 'https://github.com/aistudio/jarvis-mobile',
        'X-Title': 'JARVIS Mobile Assistant'
      },
      body: JSON.stringify({
        model: model || 'anthropic/claude-3.5-sonnet',
        messages,
        temperature,
        max_tokens
      })
    });

    const data = await openRouterResponse.json();

    if (!openRouterResponse.ok) {
      return res.status(openRouterResponse.status).json(data);
    }

    return res.json(data);
  } catch (error) {
    console.error('Error contacting OpenRouter:', error);
    return res.status(502).json({
      error: {
        message: `Gateway Error contacting OpenRouter: ${error.message}`
      }
    });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[JARVIS Proxy] Server running on http://0.0.0.0:${PORT}`);
  console.log(`[JARVIS Proxy] OpenRouter Key configured: ${Boolean(process.env.OPENROUTER_API_KEY)}`);
});
