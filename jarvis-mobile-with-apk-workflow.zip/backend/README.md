# JARVIS Mobile — Secure OpenRouter Backend

This minimal backend keeps your `OPENROUTER_API_KEY` completely safe on the server side, ensuring no secrets are exposed in distributed Android APK files.

## Local Quick Start

1. Install dependencies:
   ```bash
   cd backend
   npm install
   ```

2. Configure environment:
   ```bash
   cp .env.example .env
   # Edit .env and set OPENROUTER_API_KEY=sk-or-v1-...
   ```

3. Start server:
   ```bash
   npm start
   # Server listens on http://localhost:3000
   ```

4. Android Emulator connection:
   The Android emulator accesses host machine's localhost via `http://10.0.2.2:3000/api/chat`.
   This is the default URL configured in the JARVIS Mobile Settings screen.

## Cloud Deployment (1-Click)

### Render / Railway / Fly.io / Cloud Run
1. Connect your repository.
2. Set root directory to `backend`.
3. Add the environment variable:
   - `OPENROUTER_API_KEY`: your secret OpenRouter API key.
4. Set Build Command: `npm install`
5. Set Start Command: `node server.js`
6. Copy your public deployment URL (e.g. `https://jarvis-backend.onrender.com/api/chat`) and paste it into the **JARVIS Mobile Settings > Backend Proxy URL** field.
