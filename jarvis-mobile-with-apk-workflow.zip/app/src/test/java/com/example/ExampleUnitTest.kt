package com.example

import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.TaskReminderEntity
import com.example.data.remote.OpenRouterMessage
import com.example.data.remote.OpenRouterRequest
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testChatMessageEntityCreation() {
        val message = ChatMessageEntity(
            role = "user",
            content = "JARVIS, status scan",
            modelUsed = "anthropic/claude-3.5-sonnet"
        )
        assertEquals("user", message.role)
        assertEquals("JARVIS, status scan", message.content)
        assertTrue(message.timestamp > 0)
    }

    @Test
    fun testTaskReminderEntity() {
        val task = TaskReminderEntity(
            title = "Upgrade Arc Reactor",
            priority = "HIGH"
        )
        assertEquals("Upgrade Arc Reactor", task.title)
        assertEquals("HIGH", task.priority)
        assertEquals(false, task.isCompleted)
    }

    @Test
    fun testOpenRouterRequestSerialization() {
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val adapter = moshi.adapter(OpenRouterRequest::class.java)

        val request = OpenRouterRequest(
            model = "google/gemini-2.0-flash-001",
            messages = listOf(
                OpenRouterMessage("system", "You are JARVIS"),
                OpenRouterMessage("user", "Hello")
            ),
            temperature = 0.7,
            maxTokens = 1000
        )

        val json = adapter.toJson(request)
        assertNotNull(json)
        assertTrue(json.contains("google/gemini-2.0-flash-001"))
        assertTrue(json.contains("You are JARVIS"))
    }
}
