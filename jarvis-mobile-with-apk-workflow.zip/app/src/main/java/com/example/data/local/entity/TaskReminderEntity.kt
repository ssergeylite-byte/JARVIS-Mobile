package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks_reminders")
data class TaskReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val details: String = "",
    val isCompleted: Boolean = false,
    val priority: String = "NORMAL", // "LOW", "NORMAL", "HIGH"
    val timestamp: Long = System.currentTimeMillis()
)
