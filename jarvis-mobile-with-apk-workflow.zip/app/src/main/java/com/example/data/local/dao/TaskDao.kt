package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.TaskReminderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks_reminders ORDER BY isCompleted ASC, timestamp DESC")
    fun getAllTasksFlow(): Flow<List<TaskReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskReminderEntity): Long

    @Update
    suspend fun updateTask(task: TaskReminderEntity)

    @Delete
    suspend fun deleteTask(task: TaskReminderEntity)

    @Query("DELETE FROM tasks_reminders WHERE id = :id")
    suspend fun deleteTaskById(id: Long)

    @Query("UPDATE tasks_reminders SET isCompleted = :isCompleted WHERE id = :id")
    suspend fun updateCompletion(id: Long, isCompleted: Boolean)
}
