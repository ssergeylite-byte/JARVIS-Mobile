package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class JarvisPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_BACKEND_URL = "backend_url"
        private const val KEY_USE_BACKEND_PROXY = "use_backend_proxy"
        private const val KEY_DIRECT_API_KEY = "direct_api_key"
        private const val KEY_MODEL_ID = "model_id"
        private const val KEY_VOICE_LANGUAGE = "voice_language" // "ru-RU" or "en-US"
        private const val KEY_TTS_PITCH = "tts_pitch"
        private const val KEY_TTS_SPEED = "tts_speed"
        private const val KEY_AUTO_SPEAK = "auto_speak"
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"

        const val DEFAULT_BACKEND_URL = "http://10.0.2.2:3000/api/chat"
        const val DEFAULT_MODEL_ID = "anthropic/claude-3.5-sonnet"
        const val DEFAULT_LANGUAGE = "ru-RU"
        const val DEFAULT_TTS_PITCH = 1.18f
        const val DEFAULT_TTS_SPEED = 1.0f
        const val DEFAULT_ASSISTANT_NAME = "J.A.R.V.I.S."
        const val DEFAULT_SYSTEM_PROMPT =
            "You are J.A.R.V.I.S., a witty, highly intelligent, concise, and futuristic AI personal assistant with an Iron Man aesthetic. Respond in the user's language (prefer Russian if spoken to in Russian, or English if in English). Address the user politely (e.g., 'Сэр', 'Sir'). Keep spoken responses clear, actionable, and elegant."
    }

    var backendUrl: String
        get() = prefs.getString(KEY_BACKEND_URL, DEFAULT_BACKEND_URL) ?: DEFAULT_BACKEND_URL
        set(value) = prefs.edit().putString(KEY_BACKEND_URL, value.trim()).apply()

    var useBackendProxy: Boolean
        get() = prefs.getBoolean(KEY_USE_BACKEND_PROXY, true)
        set(value) = prefs.edit().putBoolean(KEY_USE_BACKEND_PROXY, value).apply()

    var directApiKey: String
        get() = prefs.getString(KEY_DIRECT_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_DIRECT_API_KEY, value.trim()).apply()

    var modelId: String
        get() = prefs.getString(KEY_MODEL_ID, DEFAULT_MODEL_ID) ?: DEFAULT_MODEL_ID
        set(value) = prefs.edit().putString(KEY_MODEL_ID, value.trim()).apply()

    var voiceLanguage: String
        get() = prefs.getString(KEY_VOICE_LANGUAGE, DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE
        set(value) = prefs.edit().putString(KEY_VOICE_LANGUAGE, value).apply()

    var ttsPitch: Float
        get() = prefs.getFloat(KEY_TTS_PITCH, DEFAULT_TTS_PITCH)
        set(value) = prefs.edit().putFloat(KEY_TTS_PITCH, value).apply()

    var ttsSpeed: Float
        get() = prefs.getFloat(KEY_TTS_SPEED, DEFAULT_TTS_SPEED)
        set(value) = prefs.edit().putFloat(KEY_TTS_SPEED, value).apply()

    var autoSpeak: Boolean
        get() = prefs.getBoolean(KEY_AUTO_SPEAK, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_SPEAK, value).apply()

    var assistantName: String
        get() = prefs.getString(KEY_ASSISTANT_NAME, DEFAULT_ASSISTANT_NAME) ?: DEFAULT_ASSISTANT_NAME
        set(value) = prefs.edit().putString(KEY_ASSISTANT_NAME, value).apply()

    var systemPrompt: String
        get() = prefs.getString(KEY_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT
        set(value) = prefs.edit().putString(KEY_SYSTEM_PROMPT, value).apply()
}
