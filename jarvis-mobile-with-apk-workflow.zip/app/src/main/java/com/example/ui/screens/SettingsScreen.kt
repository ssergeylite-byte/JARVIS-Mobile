package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.JarvisPreferences
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisCyanDim
import com.example.ui.theme.JarvisNeonGreen
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun SettingsScreen(
    preferences: JarvisPreferences,
    onTestVoice: () -> Unit,
    modifier: Modifier = Modifier
) {
    var useProxy by remember { mutableStateOf(preferences.useBackendProxy) }
    var backendUrl by remember { mutableStateOf(preferences.backendUrl) }
    var directApiKey by remember { mutableStateOf(preferences.directApiKey) }
    var showKey by remember { mutableStateOf(false) }
    var modelId by remember { mutableStateOf(preferences.modelId) }
    var voiceLanguage by remember { mutableStateOf(preferences.voiceLanguage) }
    var ttsPitch by remember { mutableFloatStateOf(preferences.ttsPitch) }
    var ttsSpeed by remember { mutableFloatStateOf(preferences.ttsSpeed) }
    var autoSpeak by remember { mutableStateOf(preferences.autoSpeak) }
    var assistantName by remember { mutableStateOf(preferences.assistantName) }
    var systemPrompt by remember { mutableStateOf(preferences.systemPrompt) }

    val popularModels = listOf(
        "anthropic/claude-3.5-sonnet",
        "google/gemini-2.0-flash-001",
        "meta-llama/llama-3.3-70b-instruct",
        "openai/gpt-4o-mini"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisBackground)
            .padding(16.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 36.dp)
    ) {
        // Section: AI Provider & OpenRouter Configuration
        item {
            SettingsSectionHeader(title = "OPENROUTER AI CONFIGURATION", icon = Icons.Default.Security)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = JarvisSurfaceElevated),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Mode selector: Backend Proxy vs Direct Key
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Use Secure Backend Proxy",
                                color = JarvisTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Reads OPENROUTER_API_KEY on server. Zero key in APK.",
                                color = JarvisTextMuted,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = useProxy,
                            onCheckedChange = {
                                useProxy = it
                                preferences.useBackendProxy = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = JarvisBackground,
                                checkedTrackColor = JarvisCyan,
                                uncheckedTrackColor = JarvisSurface
                            ),
                            modifier = Modifier.testTag("use_backend_proxy_switch")
                        )
                    }

                    if (useProxy) {
                        OutlinedTextField(
                            value = backendUrl,
                            onValueChange = {
                                backendUrl = it
                                preferences.backendUrl = it
                            },
                            label = { Text("Backend Proxy URL", color = JarvisTextSecondary, fontSize = 11.sp) },
                            placeholder = { Text("http://10.0.2.2:3000/api/chat", color = JarvisTextMuted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = JarvisCyan,
                                unfocusedBorderColor = JarvisSurfaceBorder,
                                focusedTextColor = JarvisTextPrimary,
                                unfocusedTextColor = JarvisTextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("backend_url_input")
                        )
                    } else {
                        OutlinedTextField(
                            value = directApiKey,
                            onValueChange = {
                                directApiKey = it
                                preferences.directApiKey = it
                            },
                            label = { Text("Direct OpenRouter API Key", color = JarvisTextSecondary, fontSize = 11.sp) },
                            placeholder = { Text("sk-or-v1-...", color = JarvisTextMuted) },
                            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showKey = !showKey }) {
                                    Icon(
                                        imageVector = if (showKey) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle key visibility",
                                        tint = JarvisCyanDim
                                    )
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = JarvisCyan,
                                unfocusedBorderColor = JarvisSurfaceBorder,
                                focusedTextColor = JarvisTextPrimary,
                                unfocusedTextColor = JarvisTextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("direct_api_key_input")
                        )
                    }

                    // Model Selection
                    Text(
                        text = "OPENROUTER MODEL ID",
                        color = JarvisCyanDim,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = modelId,
                        onValueChange = {
                            modelId = it
                            preferences.modelId = it
                        },
                        label = { Text("Model ID", color = JarvisTextSecondary, fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = JarvisCyan,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("model_id_input")
                    )

                    // Popular Model Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        popularModels.take(2).forEach { m ->
                            val isSelected = modelId == m
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) JarvisCyan else JarvisSurface)
                                    .border(1.dp, if (isSelected) JarvisCyanBright else JarvisSurfaceBorder, RoundedCornerShape(4.dp))
                                    .clickable {
                                        modelId = m
                                        preferences.modelId = m
                                    }
                                    .padding(vertical = 6.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = m.substringAfter("/"),
                                    color = if (isSelected) JarvisBackground else JarvisTextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Natural Russian Female Voice & TTS Tuning
        item {
            SettingsSectionHeader(title = "VOICE ENGINE & RUSSIAN FEMALE TTS", icon = Icons.Default.RecordVoiceOver)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = JarvisSurfaceElevated),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Language Selection
                    Text(
                        text = "VOICE LANGUAGE MATRIX",
                        color = JarvisCyanDim,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isRu = voiceLanguage.startsWith("ru", true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isRu) JarvisCyan else JarvisSurface)
                                .border(1.dp, if (isRu) JarvisCyanBright else JarvisSurfaceBorder, RoundedCornerShape(6.dp))
                                .clickable {
                                    voiceLanguage = "ru-RU"
                                    preferences.voiceLanguage = "ru-RU"
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🇷🇺 РУССКИЙ (Female)",
                                color = if (isRu) JarvisBackground else JarvisTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (!isRu) JarvisCyan else JarvisSurface)
                                .border(1.dp, if (!isRu) JarvisCyanBright else JarvisSurfaceBorder, RoundedCornerShape(6.dp))
                                .clickable {
                                    voiceLanguage = "en-US"
                                    preferences.voiceLanguage = "en-US"
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🇬🇧 ENGLISH",
                                color = if (!isRu) JarvisBackground else JarvisTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Voice Pitch Slider (Fine-tuned for feminine AI timbre)
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Voice Pitch (Feminine Harmonics)", color = JarvisTextPrimary, fontSize = 12.sp)
                            Text(
                                String.format(java.util.Locale.US, "%.2fx", ttsPitch),
                                color = JarvisCyanBright,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Slider(
                            value = ttsPitch,
                            onValueChange = {
                                ttsPitch = it
                                preferences.ttsPitch = it
                            },
                            valueRange = 0.7f..1.6f,
                            colors = SliderDefaults.colors(
                                thumbColor = JarvisCyanBright,
                                activeTrackColor = JarvisCyan,
                                inactiveTrackColor = JarvisSurface
                            ),
                            modifier = Modifier.testTag("pitch_slider")
                        )
                    }

                    // Voice Speed Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Speech Cadence (Rate)", color = JarvisTextPrimary, fontSize = 12.sp)
                            Text(
                                String.format(java.util.Locale.US, "%.2fx", ttsSpeed),
                                color = JarvisCyanBright,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Slider(
                            value = ttsSpeed,
                            onValueChange = {
                                ttsSpeed = it
                                preferences.ttsSpeed = it
                            },
                            valueRange = 0.7f..1.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = JarvisCyanBright,
                                activeTrackColor = JarvisCyan,
                                inactiveTrackColor = JarvisSurface
                            ),
                            modifier = Modifier.testTag("speed_slider")
                        )
                    }

                    // Auto-Speak Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Auto-Speak AI Responses", color = JarvisTextPrimary, fontSize = 13.sp)
                            Text("Spoken audio vocalization upon reply", color = JarvisTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = autoSpeak,
                            onCheckedChange = {
                                autoSpeak = it
                                preferences.autoSpeak = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = JarvisBackground,
                                checkedTrackColor = JarvisCyan,
                                uncheckedTrackColor = JarvisSurface
                            ),
                            modifier = Modifier.testTag("auto_speak_switch")
                        )
                    }

                    // Test Voice Button
                    Button(
                        onClick = onTestVoice,
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, JarvisCyan, RoundedCornerShape(6.dp))
                            .testTag("test_voice_button"),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Test voice",
                            tint = JarvisCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TEST VOICE SYNTHESIS",
                            color = JarvisCyanBright,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Section: Personality & System Identity
        item {
            SettingsSectionHeader(title = "ASSISTANT PROTOCOL & IDENTITY", icon = Icons.Default.Tune)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = JarvisSurfaceElevated),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = assistantName,
                        onValueChange = {
                            assistantName = it
                            preferences.assistantName = it
                        },
                        label = { Text("Call-sign / Name", color = JarvisTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = JarvisCyan,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("assistant_name_input")
                    )

                    OutlinedTextField(
                        value = systemPrompt,
                        onValueChange = {
                            systemPrompt = it
                            preferences.systemPrompt = it
                        },
                        label = { Text("System Directive / Prompt", color = JarvisTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = JarvisCyan,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary
                        ),
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth().testTag("system_prompt_input")
                    )
                }
            }
        }

        // Section: Secure Backend Deployment Architecture
        item {
            SettingsSectionHeader(title = "SECURE BACKEND ARCHITECTURE", icon = Icons.Default.Code)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = JarvisSurfaceElevated),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = JarvisNeonGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Zero API Key Leakage Standard",
                            color = JarvisNeonGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Text(
                        text = "The minimal Node.js / Docker proxy is provided in '/backend'. It reads OPENROUTER_API_KEY from environment variables and forwards authorized requests to OpenRouter. Deploy to Cloud Run, Render, or Railway with 1 command, or test locally via 10.0.2.2:3000.",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = JarvisCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            color = JarvisCyanBright,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}
