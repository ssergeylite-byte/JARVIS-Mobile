package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JARVIS Sci-Fi Hologram Color Palette
val JarvisBackground = Color(0xFF030712)
val JarvisSurface = Color(0xFF070E20)
val JarvisSurfaceElevated = Color(0xFF0D1730)
val JarvisSurfaceBorder = Color(0xFF162B50)

// Hologram Cyan & Electric Blue
val JarvisCyan = Color(0xFF00E5FF)
val JarvisCyanBright = Color(0xFF84FFFF)
val JarvisCyanDim = Color(0xFF00838F)
val JarvisCyanGlow = Color(0x3300E5FF)

val JarvisElectricBlue = Color(0xFF2979FF)
val JarvisDeepBlue = Color(0xFF1565C0)

// Status & Accent Colors
val JarvisArcAmber = Color(0xFFFFB300)
val JarvisNeonGreen = Color(0xFF00E676)
val JarvisAlertRed = Color(0xFFFF1744)

// Text Colors
val JarvisTextPrimary = Color(0xFFE0F7FA)
val JarvisTextSecondary = Color(0xFF80DEEA)
val JarvisTextMuted = Color(0xFF455A64)
