package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.ArcReactorCore
import com.example.ui.components.HudChatView
import com.example.ui.components.HudHeader
import com.example.ui.components.SoundWaveVisualizer
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisCyanDim
import com.example.ui.theme.JarvisElectricBlue
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.viewmodel.CoreMode
import com.example.viewmodel.JarvisViewModel

@Composable
fun JarvisMainScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Audio Permission Request Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleVoiceInput(true)
        }
    }

    val hasAudioPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = JarvisBackground,
        topBar = {
            HudHeader(
                assistantName = viewModel.preferences.assistantName,
                telemetry = uiState.telemetry,
                currentLanguage = viewModel.preferences.voiceLanguage,
                onLanguageToggle = {
                    val current = viewModel.preferences.voiceLanguage
                    val next = if (current.startsWith("ru", true)) "en-US" else "ru-RU"
                    viewModel.preferences.voiceLanguage = next
                }
            )
        },
        bottomBar = {
            HudBottomNavigation(
                activeTab = uiState.activeTab,
                onSelectTab = { viewModel.setActiveTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Sci-fi Hologram Background Asset
            Image(
                painter = painterResource(id = R.drawable.jarvis_hud_bg_1793065448215),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.18f)
            )

            // Active Tab Content
            when (uiState.activeTab) {
                0 -> CoreDashboardTab(
                    uiState = uiState,
                    assistantName = viewModel.preferences.assistantName,
                    onCoreClick = {
                        if (hasAudioPermission) {
                            viewModel.toggleVoiceInput(true)
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onQuickCommand = { cmd -> viewModel.processUserMessage(cmd) },
                    onStopSpeaking = { viewModel.stopSpeaking() }
                )
                1 -> HudChatView(
                    messages = uiState.messages,
                    onSendMessage = { text -> viewModel.processUserMessage(text) },
                    onSpeakMessage = { text -> viewModel.speakText(text) },
                    onClearHistory = { viewModel.clearChatHistory() }
                )
                2 -> ToolsScreen(
                    tasks = uiState.tasks,
                    onAddTask = { title, details, priority -> viewModel.addTask(title, details, priority) },
                    onToggleTask = { id, comp -> viewModel.toggleTask(id, comp) },
                    onDeleteTask = { id -> viewModel.deleteTask(id) },
                    onLaunchCamera = { viewModel.telemetryManager.launchCamera() },
                    onLaunchAlarms = { viewModel.telemetryManager.launchAlarms() },
                    onLaunchDialer = { viewModel.telemetryManager.launchDialer() },
                    onLaunchBrowser = { viewModel.telemetryManager.launchBrowser() },
                    onLaunchSettings = { viewModel.telemetryManager.launchSettings() },
                    onRunDiagnostics = { viewModel.processUserMessage("диагностика") }
                )
                3 -> SettingsScreen(
                    preferences = viewModel.preferences,
                    onTestVoice = { viewModel.testVoice() }
                )
            }

            // Error Overlay Banner
            AnimatedVisibility(
                visible = uiState.errorMessage != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                uiState.errorMessage?.let { err ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = JarvisSurfaceElevated),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, JarvisAlertRed, RoundedCornerShape(8.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Alert",
                                tint = JarvisAlertRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = err,
                                color = JarvisTextPrimary,
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearError() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss error",
                                    tint = JarvisTextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Permission Dialog
    if (uiState.showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.onPermissionDismissed() },
            containerColor = JarvisSurfaceElevated,
            title = {
                Text(
                    "MICROPHONE SENSOR AUTHORIZATION",
                    color = JarvisCyanBright,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    "JARVIS requires microphone access for vocal interactions and speech recognition. Please grant audio recording permission.",
                    color = JarvisTextPrimary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onPermissionDismissed()
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan)
                ) {
                    Text("AUTHORIZE", color = JarvisBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.onPermissionDismissed() }) {
                    Text("CANCEL", color = JarvisTextMuted)
                }
            }
        )
    }
}

@Composable
fun CoreDashboardTab(
    uiState: com.example.viewmodel.JarvisUiState,
    assistantName: String,
    onCoreClick: () -> Unit,
    onQuickCommand: (String) -> Unit,
    onStopSpeaking: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Status HUD Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(JarvisSurface.copy(alpha = 0.85f))
                .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(6.dp))
                .padding(vertical = 8.dp, horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = uiState.statusMessage,
                color = when (uiState.coreMode) {
                    CoreMode.LISTENING -> JarvisCyanBright
                    CoreMode.THINKING -> JarvisElectricBlue
                    CoreMode.SPEAKING -> JarvisCyan
                    CoreMode.ERROR -> JarvisAlertRed
                    else -> JarvisTextSecondary
                },
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Center Arc Reactor Core
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.weight(1f)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ArcReactorCore(
                    coreMode = uiState.coreMode,
                    soundLevel = uiState.soundLevel,
                    onClick = onCoreClick,
                    size = 230.dp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = when (uiState.coreMode) {
                        CoreMode.IDLE -> "TAP CORE OR MIC TO INITIATE"
                        CoreMode.LISTENING -> "LISTENING... SPEAK NOW"
                        CoreMode.THINKING -> "PROCESSING QUERY VIA OPENROUTER"
                        CoreMode.SPEAKING -> "VOCAL SYNTHESIS ENGAGED"
                        CoreMode.ERROR -> "COMM LINK ERROR // TAP TO RESET"
                    },
                    color = JarvisTextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                // Partial recognized speech
                if (uiState.partialSpeech.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\"${uiState.partialSpeech}\"",
                        color = JarvisCyanBright,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }

                // Stop Speaking Action Button if TTS is active
                if (uiState.isTtsSpeaking) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onStopSpeaking,
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisSurfaceElevated),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.border(1.dp, JarvisCyan, RoundedCornerShape(20.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop voice output",
                            tint = JarvisCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "MUTE VOCAL OUTPUT",
                            color = JarvisCyan,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Sound-Wave Frequency Visualizer
        SoundWaveVisualizer(
            isActive = uiState.coreMode == CoreMode.LISTENING || uiState.coreMode == CoreMode.SPEAKING,
            soundLevel = uiState.soundLevel,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Telemetry & Command Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            QuickChip(
                label = "📊 СТАТУС",
                onClick = { onQuickCommand("диагностика систем") },
                modifier = Modifier.weight(1f)
            )
            QuickChip(
                label = "📷 КАМЕРА",
                onClick = { onQuickCommand("открой камеру") },
                modifier = Modifier.weight(1f)
            )
            QuickChip(
                label = "📋 ЗАДАЧИ",
                onClick = { onQuickCommand("покажи задачи") },
                modifier = Modifier.weight(1f)
            )
            QuickChip(
                label = "⏰ БУДИЛЬНИК",
                onClick = { onQuickCommand("открой будильник") },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
fun QuickChip(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(JarvisSurface)
            .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = JarvisTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun HudBottomNavigation(
    activeTab: Int,
    onSelectTab: (Int) -> Unit
) {
    val items = listOf(
        Triple(0, "CORE", Icons.Default.RadioButtonChecked),
        Triple(1, "COMMS", Icons.Default.Chat),
        Triple(2, "TOOLS", Icons.Default.Build),
        Triple(3, "SETTINGS", Icons.Default.Settings)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(JarvisSurface)
            .border(1.dp, JarvisSurfaceBorder)
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (index, title, icon) ->
            val isSelected = activeTab == index
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSelectTab(index) }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .testTag("nav_tab_$index"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isSelected) JarvisCyanBright else JarvisTextMuted,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = title,
                    color = if (isSelected) JarvisCyanBright else JarvisTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}
