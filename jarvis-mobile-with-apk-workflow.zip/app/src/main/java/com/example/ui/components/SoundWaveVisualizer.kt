package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisElectricBlue
import kotlin.math.sin

@Composable
fun SoundWaveVisualizer(
    isActive: Boolean,
    soundLevel: Float, // 0.0 .. 1.0
    modifier: Modifier = Modifier,
    barCount: Int = 28,
    height: Dp = 48.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "soundwave_wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f, // 2*PI
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase_anim"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val totalWidth = size.width
        val maxHeight = size.height
        val barWidth = (totalWidth / (barCount * 1.5f)).coerceIn(3f, 12f)
        val spacing = (totalWidth - (barWidth * barCount)) / (barCount - 1)
        val centerY = maxHeight / 2

        val gradient = Brush.verticalGradient(
            colors = listOf(
                JarvisCyanBright,
                JarvisCyan,
                JarvisElectricBlue
            )
        )

        for (i in 0 until barCount) {
            val progress = i.toFloat() / barCount
            val wave = if (isActive) {
                val harmonic = sin(progress * 8f + phase) * 0.5f + 0.5f
                val amplitudeFactor = (0.2f + soundLevel * 0.8f).coerceIn(0.15f, 1.0f)
                (harmonic * amplitudeFactor).coerceIn(0.1f, 1f)
            } else {
                0.08f // resting baseline state
            }

            val barHeight = (maxHeight * wave).coerceAtLeast(4f)
            val left = i * (barWidth + spacing)
            val top = centerY - (barHeight / 2)

            drawRoundRect(
                brush = gradient,
                topLeft = Offset(left, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}
