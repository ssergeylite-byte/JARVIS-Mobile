package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisCyanGlow
import com.example.ui.theme.JarvisElectricBlue
import com.example.ui.theme.JarvisNeonGreen
import com.example.viewmodel.CoreMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorCore(
    coreMode: CoreMode,
    soundLevel: Float, // 0.0 .. 1.0
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 240.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactor_anim")

    // Outer slow rotation
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (coreMode == CoreMode.THINKING) 3000 else 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rot"
    )

    // Inner counter rotation
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (coreMode == CoreMode.THINKING) 2000 else 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rot"
    )

    // Core pulsing scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (coreMode == CoreMode.THINKING) 400 else 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Dynamic sound-reactive scale factor
    val soundReactiveAnim = remember { Animatable(0f) }
    LaunchedEffect(soundLevel) {
        soundReactiveAnim.animateTo(
            targetValue = soundLevel,
            animationSpec = tween(durationMillis = 60, easing = LinearEasing)
        )
    }

    // Determine color schemes based on mode
    val (primaryGlowColor, accentColor) = when (coreMode) {
        CoreMode.IDLE -> Pair(JarvisCyan, JarvisElectricBlue)
        CoreMode.LISTENING -> Pair(JarvisNeonGreen, JarvisCyanBright)
        CoreMode.THINKING -> Pair(JarvisCyanBright, JarvisElectricBlue)
        CoreMode.SPEAKING -> Pair(JarvisCyan, JarvisCyanBright)
        CoreMode.ERROR -> Pair(JarvisAlertRed, Color(0xFFFF5722))
    }

    val dynamicBoost = if (coreMode == CoreMode.LISTENING || coreMode == CoreMode.SPEAKING) {
        soundReactiveAnim.value * 0.25f
    } else 0f

    val finalScale = (pulseScale + dynamicBoost).coerceIn(0.85f, 1.4f)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .testTag("arc_reactor_core")
            .semantics { contentDescription = "JARVIS Arc Reactor Core Button" }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = size / 2),
                onClick = onClick
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val baseRadius = this.size.minDimension / 2 * 0.92f

            // 1. Outermost glow halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(primaryGlowColor.copy(alpha = 0.35f + dynamicBoost * 0.3f), Color.Transparent),
                    center = center,
                    radius = baseRadius * 1.15f
                ),
                radius = baseRadius * 1.15f,
                center = center
            )

            // 2. Rotating Outer Segmented Ring
            rotate(outerRotation, pivot = center) {
                // Dashed outer boundary
                drawCircle(
                    color = primaryGlowColor.copy(alpha = 0.45f),
                    radius = baseRadius,
                    center = center,
                    style = Stroke(
                        width = 2.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f), 0f)
                    )
                )

                // 4 Quadrant Accent Arcs
                for (i in 0 until 4) {
                    val startAngle = i * 90f + 10f
                    drawArc(
                        color = accentColor,
                        startAngle = startAngle,
                        sweepAngle = 70f,
                        useCenter = false,
                        topLeft = Offset(center.x - baseRadius, center.y - baseRadius),
                        size = Size(baseRadius * 2, baseRadius * 2),
                        style = Stroke(width = 4f, cap = StrokeCap.Round)
                    )
                }

                // Tick marks along outer ring
                val numTicks = 24
                for (t in 0 until numTicks) {
                    val angleRad = (t * (360f / numTicks)) * (PI / 180f)
                    val r1 = baseRadius - 10f
                    val r2 = baseRadius - 2f
                    val p1 = Offset((center.x + r1 * cos(angleRad)).toFloat(), (center.y + r1 * sin(angleRad)).toFloat())
                    val p2 = Offset((center.x + r2 * cos(angleRad)).toFloat(), (center.y + r2 * sin(angleRad)).toFloat())
                    drawLine(
                        color = primaryGlowColor.copy(alpha = if (t % 3 == 0) 0.8f else 0.3f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (t % 3 == 0) 2.5f else 1.2f
                    )
                }
            }

            // 3. Rotating Middle Ring (Counter-clockwise)
            val middleRadius = baseRadius * 0.76f
            rotate(innerRotation, pivot = center) {
                drawCircle(
                    color = accentColor.copy(alpha = 0.5f),
                    radius = middleRadius,
                    center = center,
                    style = Stroke(
                        width = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 20f), 0f)
                    )
                )

                // High-tech circular nodes
                for (node in 0 until 6) {
                    val nodeAngle = (node * 60f) * (PI / 180f)
                    val nodePos = Offset(
                        (center.x + middleRadius * cos(nodeAngle)).toFloat(),
                        (center.y + middleRadius * sin(nodeAngle)).toFloat()
                    )
                    drawCircle(
                        color = primaryGlowColor,
                        radius = 4f + dynamicBoost * 3f,
                        center = nodePos
                    )
                }
            }

            // 4. Inner Ring with Solid Circuit Accents
            val innerRadius = baseRadius * 0.55f * finalScale
            drawCircle(
                color = primaryGlowColor.copy(alpha = 0.7f),
                radius = innerRadius,
                center = center,
                style = Stroke(width = 3f)
            )

            // Inner glowing chamber
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        JarvisCyanBright.copy(alpha = 0.9f),
                        primaryGlowColor.copy(alpha = 0.5f),
                        JarvisBackground.copy(alpha = 0.85f)
                    ),
                    center = center,
                    radius = innerRadius
                ),
                radius = innerRadius,
                center = center
            )
        }

        // Center Action Icon
        val centerIcon = when (coreMode) {
            CoreMode.IDLE -> Icons.Filled.Mic
            CoreMode.LISTENING -> Icons.Filled.Stop
            CoreMode.THINKING -> Icons.Filled.GraphicEq
            CoreMode.SPEAKING -> Icons.Filled.GraphicEq
            CoreMode.ERROR -> Icons.Filled.PowerSettingsNew
        }

        Icon(
            imageVector = centerIcon,
            contentDescription = "Microphone action trigger",
            tint = JarvisCyanBright,
            modifier = Modifier.size(38.dp)
        )
    }
}
