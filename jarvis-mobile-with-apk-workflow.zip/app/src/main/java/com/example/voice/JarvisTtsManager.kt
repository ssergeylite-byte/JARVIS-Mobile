package com.example.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.local.JarvisPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.random.Random

class JarvisTtsManager(
    private val context: Context,
    private val preferences: JarvisPreferences
) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "JarvisTTS"
        private const val UTTERANCE_ID = "jarvis_speech_utterance"
    }

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main)
    private var amplitudeJob: Job? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupVoice()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                    startSimulatedAmplitude()
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    stopSimulatedAmplitude()
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    stopSimulatedAmplitude()
                }
            })
            Log.d(TAG, "TTS initialized successfully.")
        } else {
            Log.e(TAG, "TTS initialization failed with code $status")
        }
    }

    fun setupVoice() {
        val tts = this.tts ?: return
        if (!isInitialized) return

        val langCode = preferences.voiceLanguage
        val targetLocale = if (langCode.startsWith("ru", ignoreCase = true)) {
            Locale("ru", "RU")
        } else {
            Locale.US
        }

        try {
            val langResult = tts.setLanguage(targetLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Language $targetLocale not fully supported on this device.")
            }

            // Inspect available voices for natural Russian female profile
            val voices = tts.voices
            if (!voices.isNullOrEmpty()) {
                val matchingVoices = voices.filter { voice ->
                    voice.locale.language.equals(targetLocale.language, ignoreCase = true)
                }

                // Look for feminine voice markers (e.g. dfc, female, rua, ruf)
                val femaleVoice = matchingVoices.firstOrNull { voice ->
                    val name = voice.name.lowercase(Locale.ROOT)
                    name.contains("female") ||
                            name.contains("dfc") ||
                            name.contains("rua") ||
                            name.contains("ruf") ||
                            (voice.features != null && voice.features.any { it.contains("female", ignoreCase = true) })
                } ?: matchingVoices.firstOrNull { !it.isNetworkConnectionRequired }
                ?: matchingVoices.firstOrNull()

                if (femaleVoice != null) {
                    tts.voice = femaleVoice
                    Log.d(TAG, "Selected TTS Voice: ${femaleVoice.name} for ${targetLocale.language}")
                }
            }

            // Apply fine-tuned pitch and speech rate for a natural, elegant female assistant persona
            val pitch = preferences.ttsPitch
            val speed = preferences.ttsSpeed
            tts.setPitch(pitch)
            tts.setSpeechRate(speed)
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring voice", e)
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) {
            Log.w(TAG, "TTS not ready yet")
            return
        }

        setupVoice()

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, UTTERANCE_ID)
        }

        // Clean out markdown symbols for smooth, natural audio delivery
        val cleanText = sanitizeTextForSpeech(text)
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, UTTERANCE_ID)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        stopSimulatedAmplitude()
    }

    private fun startSimulatedAmplitude() {
        amplitudeJob?.cancel()
        amplitudeJob = scope.launch {
            while (isActive && _isSpeaking.value) {
                _amplitude.value = 0.3f + Random.nextFloat() * 0.7f
                delay(80)
            }
            _amplitude.value = 0f
        }
    }

    private fun stopSimulatedAmplitude() {
        amplitudeJob?.cancel()
        amplitudeJob = null
        _amplitude.value = 0f
    }

    private fun sanitizeTextForSpeech(text: String): String {
        return text
            .replace(Regex("""[*_`#~]"""), "") // Remove markdown asterisks, backticks, hashtags
            .replace(Regex("""\[(.*?)\]\(.*?\)"""), "$1") // Replace links with just text
            .replace(Regex("""```[\s\S]*?```"""), " Блок кода. ") // Simplify code blocks in speech
            .trim()
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
