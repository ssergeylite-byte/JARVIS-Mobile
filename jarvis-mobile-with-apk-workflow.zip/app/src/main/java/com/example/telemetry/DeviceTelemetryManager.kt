package com.example.telemetry

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log

data class DeviceTelemetry(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val ramAvailableMb: Long,
    val ramTotalMb: Long,
    val networkType: String,
    val isOnline: Boolean,
    val osVersion: String,
    val deviceName: String
)

class DeviceTelemetryManager(private val context: Context) {

    companion object {
        private const val TAG = "TelemetryManager"
    }

    fun getTelemetry(): DeviceTelemetry {
        // 1. Battery
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) ((level * 100) / scale) else 100

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        // 2. RAM Memory
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)
        val ramAvailableMb = memInfo.availMem / (1024 * 1024)
        val ramTotalMb = memInfo.totalMem / (1024 * 1024)

        // 3. Network
        val connManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = connManager?.activeNetwork
        val caps = connManager?.getNetworkCapabilities(activeNetwork)
        val isOnline = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val netType = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "WI-FI GRID"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "CELLULAR LINK"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "ETHERNET BUS"
            else -> if (isOnline) "NETWORK LINKED" else "OFFLINE"
        }

        val osVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

        return DeviceTelemetry(
            batteryPercent = batteryPct,
            isCharging = isCharging,
            ramAvailableMb = ramAvailableMb,
            ramTotalMb = ramTotalMb,
            networkType = netType,
            isOnline = isOnline,
            osVersion = osVersion,
            deviceName = deviceName
        )
    }

    fun generateDiagnosticReport(isRussian: Boolean): String {
        val t = getTelemetry()
        val chargingStatus = if (t.isCharging) {
            if (isRussian) "Заряжается" else "Charging"
        } else {
            if (isRussian) "От аккумулятора" else "Discharging"
        }

        return if (isRussian) {
            """
            📊 [ДИАГНОСТИКА СИСТЕМ J.A.R.V.I.S.]
            • Статус реактора (Батарея): ${t.batteryPercent}% ($chargingStatus)
            • Оперативная память: ${t.ramAvailableMb} МБ свободно из ${t.ramTotalMb} МБ
            • Канал связи: ${t.networkType} (Статус: ${if (t.isOnline) "В СЕТИ" else "ОФФЛАЙН"})
            • Платформа: ${t.deviceName} | ${t.osVersion}
            • Ядро JARVIS: Активно, все субмодули в норме.
            """.trimIndent()
        } else {
            """
            📊 [J.A.R.V.I.S. SYSTEM TELEMETRY]
            • Core Power (Battery): ${t.batteryPercent}% ($chargingStatus)
            • Memory Buffer: ${t.ramAvailableMb} MB free of ${t.ramTotalMb} MB
            • Comms Channel: ${t.networkType} (Status: ${if (t.isOnline) "ONLINE" else "OFFLINE"})
            • Hardware: ${t.deviceName} | ${t.osVersion}
            • Core Matrix: Active, subsystems nominal.
            """.trimIndent()
        }
    }

    // Quick Action Launches
    fun launchCamera(): Boolean = tryLaunch {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun launchAlarms(): Boolean = tryLaunch {
        Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun launchDialer(phone: String = ""): Boolean = tryLaunch {
        val uri = if (phone.isNotBlank()) Uri.parse("tel:$phone") else Uri.parse("tel:")
        Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun launchBrowser(queryOrUrl: String = ""): Boolean = tryLaunch {
        val uri = if (queryOrUrl.startsWith("http://") || queryOrUrl.startsWith("https://")) {
            Uri.parse(queryOrUrl)
        } else if (queryOrUrl.isNotBlank()) {
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(queryOrUrl))
        } else {
            Uri.parse("https://www.google.com")
        }
        Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun launchSettings(): Boolean = tryLaunch {
        Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private fun tryLaunch(intentProvider: () -> Intent): Boolean {
        return try {
            val intent = intentProvider()
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch intent", e)
            false
        }
    }
}
