package com.example.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.JarvisDatabase
import com.example.data.local.JarvisPreferences
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.TaskReminderEntity
import com.example.data.remote.OpenRouterClient
import com.example.data.remote.OpenRouterMessage
import com.example.telemetry.DeviceTelemetryManager
import com.example.voice.JarvisSpeechRecognizer
import com.example.voice.JarvisTtsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "JarvisVM"
    }

    val preferences = JarvisPreferences(application)
    val telemetryManager = DeviceTelemetryManager(application)
    val ttsManager = JarvisTtsManager(application, preferences)
    val speechRecognizer = JarvisSpeechRecognizer(application)
    private val openRouterClient = OpenRouterClient(preferences)
    private val database = JarvisDatabase.getInstance(application)
    private val chatDao = database.chatDao()
    private val taskDao = database.taskDao()

    private val _uiState = MutableStateFlow(JarvisUiState())
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    private var thinkingAnimationJob: Job? = null

    init {
        // Collect messages from Room
        viewModelScope.launch {
            chatDao.getAllMessagesFlow().collectLatest { msgList ->
                _uiState.update { it.copy(messages = msgList) }
            }
        }

        // Collect tasks from Room
        viewModelScope.launch {
            taskDao.getAllTasksFlow().collectLatest { taskList ->
                _uiState.update { it.copy(tasks = taskList) }
            }
        }

        // Collect SpeechRecognizer audio levels & partial speech
        viewModelScope.launch {
            speechRecognizer.rmsDb.collectLatest { rms ->
                if (_uiState.value.coreMode == CoreMode.LISTENING) {
                    _uiState.update { it.copy(soundLevel = rms) }
                }
            }
        }

        viewModelScope.launch {
            speechRecognizer.partialText.collectLatest { partial ->
                _uiState.update { it.copy(partialSpeech = partial) }
            }
        }

        // Collect TTS state & amplitude
        viewModelScope.launch {
            ttsManager.isSpeaking.collectLatest { speaking ->
                _uiState.update {
                    it.copy(
                        isTtsSpeaking = speaking,
                        coreMode = if (speaking) CoreMode.SPEAKING else if (it.coreMode == CoreMode.SPEAKING) CoreMode.IDLE else it.coreMode,
                        statusMessage = if (speaking) "${preferences.assistantName} VOCAL OUTPUT ACTIVE" else it.statusMessage
                    )
                }
                if (!speaking && _uiState.value.coreMode == CoreMode.SPEAKING) {
                    _uiState.update { it.copy(soundLevel = 0f) }
                }
            }
        }

        viewModelScope.launch {
            ttsManager.amplitude.collectLatest { amp ->
                if (_uiState.value.coreMode == CoreMode.SPEAKING) {
                    _uiState.update { it.copy(soundLevel = amp) }
                }
            }
        }

        refreshTelemetry()
    }

    fun refreshTelemetry() {
        val t = telemetryManager.getTelemetry()
        _uiState.update { it.copy(telemetry = t) }
    }

    fun setActiveTab(index: Int) {
        _uiState.update { it.copy(activeTab = index) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    // Voice Input Trigger
    fun toggleVoiceInput(hasAudioPermission: Boolean) {
        if (!hasAudioPermission) {
            _uiState.update { it.copy(showPermissionDialog = true) }
            return
        }

        if (_uiState.value.coreMode == CoreMode.LISTENING) {
            speechRecognizer.stopListening()
            _uiState.update {
                it.copy(
                    coreMode = CoreMode.IDLE,
                    statusMessage = "STANDBY // MATRIX STABLE"
                )
            }
        } else {
            // Stop TTS if currently speaking
            ttsManager.stop()

            val lang = preferences.voiceLanguage
            _uiState.update {
                it.copy(
                    coreMode = CoreMode.LISTENING,
                    partialSpeech = "",
                    statusMessage = "LISTENING... AUDIO SENSORS ENGAGED"
                )
            }

            speechRecognizer.startListening(
                languageCode = lang,
                onFinalResult = { recognized ->
                    _uiState.update { it.copy(partialSpeech = recognized) }
                    processUserMessage(recognized)
                },
                onErrorResult = { err ->
                    _uiState.update {
                        it.copy(
                            coreMode = CoreMode.IDLE,
                            statusMessage = "STANDBY // $err",
                            errorMessage = err
                        )
                    }
                }
            )
        }
    }

    fun onPermissionDismissed() {
        _uiState.update { it.copy(showPermissionDialog = false) }
    }

    // Process User Query
    fun processUserMessage(rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isBlank()) return

        // 1. Save user message to database
        viewModelScope.launch(Dispatchers.IO) {
            chatDao.insertMessage(
                ChatMessageEntity(
                    role = "user",
                    content = query
                )
            )
        }

        // 2. Intercept local quick commands (Camera, Telemetry, Reminders, Alarms)
        val lower = query.lowercase()
        val isRussian = preferences.voiceLanguage.startsWith("ru", ignoreCase = true)

        if (lower.contains("камер") || lower.contains("camera")) {
            telemetryManager.launchCamera()
            val reply = if (isRussian) "Запускаю модуль оптического захвата (камеру), сэр." else "Optical sensors engaged. Opening camera, Sir."
            deliverAssistantResponse(reply)
            return
        }

        if (lower.contains("диагностик") || lower.contains("телеметри") || lower.contains("статус систем") ||
            lower.contains("telemetry") || lower.contains("system status") || lower.contains("diagnostics")
        ) {
            val report = telemetryManager.generateDiagnosticReport(isRussian)
            val spokenReport = if (isRussian) {
                "Диагностика завершена. Заряд реактора: ${telemetryManager.getTelemetry().batteryPercent}%. Память и канал связи в норме."
            } else {
                "Telemetry complete. Battery at ${telemetryManager.getTelemetry().batteryPercent} percent. All core matrices stable."
            }
            deliverAssistantResponse(report, spokenOverride = spokenReport)
            return
        }

        if (lower.contains("будильник") || lower.contains("таймер") || lower.contains("alarm")) {
            telemetryManager.launchAlarms()
            val reply = if (isRussian) "Открываю будильники и таймеры, сэр." else "Accessing chronometer and alarms, Sir."
            deliverAssistantResponse(reply)
            return
        }

        if (lower.contains("напомни") || lower.contains("remind me") || lower.contains("создай задачу")) {
            val taskTitle = query
                .replace(Regex("(?i)^(напомни|remind me|создай задачу|добавь напоминание)\\s*"), "")
                .trim()
                .ifBlank { if (isRussian) "Новое поручение" else "New Directive" }

            viewModelScope.launch(Dispatchers.IO) {
                taskDao.insertTask(
                    TaskReminderEntity(
                        title = taskTitle,
                        priority = "HIGH"
                    )
                )
            }
            val reply = if (isRussian) "Задача внесена в реестр: '$taskTitle', сэр." else "Task registered into memory: '$taskTitle', Sir."
            deliverAssistantResponse(reply)
            return
        }

        // 3. Delegate to OpenRouter
        queryOpenRouter(query)
    }

    private fun queryOpenRouter(userPrompt: String) {
        _uiState.update {
            it.copy(
                coreMode = CoreMode.THINKING,
                statusMessage = "NEURAL PROCESSING // QUERYING OPENROUTER"
            )
        }

        viewModelScope.launch {
            // Load conversation history for multi-turn context
            val history = chatDao.getRecentMessages(10).reversed()
            val messagesList = history.map {
                OpenRouterMessage(role = it.role, content = it.content)
            }.toMutableList()

            // If the latest message wasn't in history yet, add it
            if (messagesList.none { it.role == "user" && it.content == userPrompt }) {
                messagesList.add(OpenRouterMessage(role = "user", content = userPrompt))
            }

            val result = openRouterClient.sendChatCompletion(
                conversation = messagesList,
                systemPrompt = preferences.systemPrompt,
                modelId = preferences.modelId
            )

            result.fold(
                onSuccess = { reply ->
                    deliverAssistantResponse(reply)
                },
                onFailure = { err ->
                    Log.e(TAG, "OpenRouter failure", err)
                    val errMsg = err.message ?: "Failed to generate AI response."
                    _uiState.update {
                        it.copy(
                            coreMode = CoreMode.ERROR,
                            statusMessage = "COMMUNICATION LINK FAILURE",
                            errorMessage = errMsg
                        )
                    }

                    // Save error notice in chat so the user can see what happened
                    chatDao.insertMessage(
                        ChatMessageEntity(
                            role = "assistant",
                            content = "⚠️ [SYSTEM NOTICE]: $errMsg"
                        )
                    )

                    // Reset back to idle after a brief error display
                    delay(4000)
                    if (_uiState.value.coreMode == CoreMode.ERROR) {
                        _uiState.update {
                            it.copy(
                                coreMode = CoreMode.IDLE,
                                statusMessage = "JARVIS CORE 4.2 // ONLINE"
                            )
                        }
                    }
                }
            )
        }
    }

    private fun deliverAssistantResponse(fullText: String, spokenOverride: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            chatDao.insertMessage(
                ChatMessageEntity(
                    role = "assistant",
                    content = fullText,
                    modelUsed = preferences.modelId
                )
            )
        }

        _uiState.update {
            it.copy(
                coreMode = CoreMode.IDLE,
                statusMessage = "RESPONSE DELIVERED // SYSTEMS NOMINAL",
                partialSpeech = ""
            )
        }

        // Voice output via natural female Russian/English voice
        if (preferences.autoSpeak) {
            val textToSpeak = spokenOverride ?: fullText
            ttsManager.speak(textToSpeak)
        }
    }

    fun speakText(text: String) {
        ttsManager.speak(text)
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    fun clearChatHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            chatDao.clearHistory()
        }
    }

    // Task Management
    fun addTask(title: String, details: String = "", priority: String = "NORMAL") {
        if (title.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            taskDao.insertTask(
                TaskReminderEntity(
                    title = title.trim(),
                    details = details.trim(),
                    priority = priority
                )
            )
        }
    }

    fun toggleTask(id: Long, completed: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            taskDao.updateCompletion(id, completed)
        }
    }

    fun deleteTask(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            taskDao.deleteTaskById(id)
        }
    }

    fun testVoice() {
        val isRussian = preferences.voiceLanguage.startsWith("ru", ignoreCase = true)
        val phrase = if (isRussian) {
            "Здравствуйте, сэр. Все вспомогательные протоколы и речевые модули функционируют в штатном режиме."
        } else {
            "Greetings, Sir. Vocal harmonics and reactor protocols are operating within optimal parameters."
        }
        ttsManager.speak(phrase)
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        speechRecognizer.stopListening()
    }
}
