package com.example.viewmodel

import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.TaskReminderEntity
import com.example.telemetry.DeviceTelemetry

enum class CoreMode {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

data class JarvisUiState(
    val coreMode: CoreMode = CoreMode.IDLE,
    val statusMessage: String = "JARVIS PROTOCOL 4.2 // ONLINE",
    val partialSpeech: String = "",
    val soundLevel: Float = 0f,
    val isTtsSpeaking: Boolean = false,
    val telemetry: DeviceTelemetry? = null,
    val messages: List<ChatMessageEntity> = emptyList(),
    val tasks: List<TaskReminderEntity> = emptyList(),
    val activeTab: Int = 0, // 0 = HUD/Core, 1 = Chat Stream, 2 = Tools & Tasks, 3 = Settings
    val errorMessage: String? = null,
    val showPermissionDialog: Boolean = false
)
